import { Component, Input, OnInit } from "@angular/core";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
  FormArray,
} from "@angular/forms";
import { Router } from "@angular/router";
import { EmployeeSkills } from "../dto/employee-skills";
import { GlobelServiceService } from "../globel-service.service";
@Component({
  selector: "app-registration-form",
  templateUrl: "./registration-form.component.html",
  styleUrls: ["./registration-form.component.scss"],
})
export class RegistrationFormComponent implements OnInit {
  employeeSkills: EmployeeSkills[] = [
    { name: "HTML", checked: false },
    { name: "CSS", checked: false },
    { name: "JavaScript", checked: false },
    { name: "Angular", checked: false },
    { name: "PHP", checked: false },
  ];
  EmployeeGender = ["Male", "Female", "Other"];
  Countries = ["INDIA", "USA", "CANADA", "SINGAPUR", "UK", "FRANCE"];
  employeeExp = ["0-1", "1-3", "3-6"];
  employeeForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private service: GlobelServiceService
  ) {
    this.employeeForm = this.fb.group({
      userName: [
        "",
        [Validators.required, Validators.pattern("^[aA-zZ]\\w{3,29}$")],
      ],
      emailAddress: [
        "",
        [
          Validators.required,
          Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"),
        ],
      ],
      mobileNumber: [
        "",
        [Validators.required, Validators.pattern("[7-9][0-9]{9}")],
      ],
      gender: [null, Validators.required],
      currentLocation: ["", Validators.required],
      country: [null, Validators.required],
      experience: ["", Validators.required],
      skills: [],
    });
  }

  selectedSkills: any[] = [];
  url: any;
  ngOnInit(): void {
    if (this.router.url.includes("edit")) {
      this.patchvalue();
    }
    this.service.employyeData;
  }

  selectSkills(value, status: boolean,index) {
    if (this.selectedSkills.indexOf(value) === -1 && status) {
      this.selectedSkills.push(value);
      this.employeeSkills[index].checked = status
    } else if (!status) {
      let index = this.selectedSkills.indexOf(value);
      this.selectedSkills.splice(index, 1);
    }
    console.log(this.selectedSkills);

    // if(this.router.url.includes('edit')){
    //   status = true;
    // }
  }

  patchvalue() {
    let formData = this.service.employyeData;
    this.url = this.router.url.split("/");

    this.employeeForm.patchValue(formData[this.url[2]]);
  }

  List(){
    this.router.navigate(["viewForm"]);
  }

  Update() {
    let formData = this.service.employyeData;

    if(this.router.url.includes('edit'))
    
    formData[this.url[2]] = {
      userName: this.employeeForm.controls.userName.value,
      emailAddress: this.employeeForm.controls.emailAddress.value,
      mobileNumber: this.employeeForm.controls.mobileNumber.value,
      gender: this.employeeForm.controls.gender.value,
      currentLocation: this.employeeForm.controls.currentLocation.value,
      experience: this.employeeForm.controls.experience.value,
      skills: this.selectedSkills,
      country: this.employeeForm.controls.country.value,
    };

    this.router.navigate(["viewForm"]);
  }

  async onSubmit() {
   
    this.router.navigate(["viewForm"]);

    this.service.employyeData.push({
      userName: this.employeeForm.controls.userName.value,
      emailAddress: this.employeeForm.controls.emailAddress.value,
      mobileNumber: this.employeeForm.controls.mobileNumber.value,
      gender: this.employeeForm.controls.gender.value,
      currentLocation: this.employeeForm.controls.currentLocation.value,
      experience: this.employeeForm.controls.experience.value,
      skills: this.selectedSkills,
      country: this.employeeForm.controls.country.value,
    });
  }

  selectExp(event) {}
}
