import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { ViewEmployeeFormComponent } from './view-employee-form/view-employee-form.component';


const routes: Routes = [
  {path:'employeeForm',component:RegistrationFormComponent},
  {path:'viewForm',component:ViewEmployeeFormComponent},
  { path:'edit/:id', component:RegistrationFormComponent },
  {path:'',redirectTo:'employeeForm',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
