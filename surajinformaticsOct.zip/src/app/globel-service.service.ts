import { Injectable } from '@angular/core';
import { EmployeeSkills } from './dto/employee-skills';
import { TableData } from './dto/table-data';

@Injectable({
  providedIn: 'root'
})
export class GlobelServiceService {
values:EmployeeSkills = new EmployeeSkills();
employyeData:TableData[] = [];
skills  = []
  constructor() { 

    // console.log(this.employyeData)
    // this.employyeData['skills'] = this.skills['name']
   
  }


}
