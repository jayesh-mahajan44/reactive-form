

export class EmployeeSkills {
    name?:string;
    checked?:boolean;
    constructor(name?:string,checked?:boolean){
        this.name = name;
        this.checked = checked;
    }
}
